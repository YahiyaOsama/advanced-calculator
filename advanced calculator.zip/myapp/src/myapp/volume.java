/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

/**
 *
 * @author Yahiya osama
 */
public class volume extends javax.swing.JFrame {

      double  conv ,amount;

    public volume() {
        initComponents();
        this.setTitle("Volume Department");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        l1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        from = new javax.swing.JComboBox<>();
        l2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        to = new javax.swing.JComboBox<>();
        bconv = new javax.swing.JButton();
        bdel = new javax.swing.JButton();
        bac = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b0 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        bpoint = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        l5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Yahiya osama\\Downloads\\list.png")); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        l1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        l1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        l1.setText("0");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("From");

        from.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        from.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cubic kilometres        (km³)", "Cubic metres              (m³)", "Cubic centimetres      (cm³)", "Cubic millimetres        (mm³)", "Cubic feet                    (ft³)", "Cubic yards                 (yd³)", "Cubic miles                  (mi³)" }));

        l2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        l2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        l2.setText("0");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("To");

        to.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        to.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cubic kilometres        (km³)", "Cubic metres              (m³)", "Cubic centimetres      (cm³)", "Cubic millimetres        (mm³)", "Cubic feet                    (ft³)", "Cubic yards                 (yd³)", "Cubic miles                  (mi³)" }));

        bconv.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bconv.setText("conv");
        bconv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bconvActionPerformed(evt);
            }
        });

        bdel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bdel.setText("DEL");
        bdel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bdelActionPerformed(evt);
            }
        });

        bac.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bac.setText("AC");
        bac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bacActionPerformed(evt);
            }
        });

        b6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b6.setText("6");
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b2.setText("2");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b1.setText("1");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b5.setText("5");
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b9.setText("9");
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        b8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b8.setText("8");
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b7.setText("7");
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b3.setText("3");
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b0.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b0.setText("0");
        b0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b0ActionPerformed(evt);
            }
        });

        b4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        b4.setText("4");
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        bpoint.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bpoint.setText(".");
        bpoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bpointActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\Yahiya osama\\Documents\\NetBeansProjects\\myapp\\photos\\volume.png")); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        l5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        l5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        l5.setText("Volume");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2)
                        .addGap(91, 91, 91)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(l5, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(to, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(193, 193, 193)
                        .addComponent(bconv, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bdel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(bac, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(b0, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(bpoint, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel7)))
                .addGap(6, 6, 6)
                .addComponent(l5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(from, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(to, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bconv, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bdel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bac, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b0, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bpoint, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        list y = new list();
        y.setVisible(true);
                dispose();

    }//GEN-LAST:event_jLabel2MouseClicked

    private void bconvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bconvActionPerformed
        amount = Double.parseDouble(l1.getText());
       if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*1 ;
            l2.setText(String.valueOf(conv));
        } else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*1 ;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*Math.pow(10, 10);
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*1E-10;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*Math.pow(10, 12);
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*1E-12;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && "Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.386102;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*2.58999;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.386102;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  feet                    (ft³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*9.2903E-8;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*1.196E+6;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*8.36127E-7;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*1000000;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*1E-6;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*10000;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.0001;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  feet (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*10.7639;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  feet (ft³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.0929;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*1.19599;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.836127;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.86102E-7;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*2.59E+6;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*100;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.01;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.00107639;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  feet                    (ft³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*929.03;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.00012;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*8361.27;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && "Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.86102E-11;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*2.59E+10;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*1.07639E-5;
            l2.setText(String.valueOf(conv));
        }else if("  Cubic  feet                    (ft³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*92903.04;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*1.19599E-6;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*836127.36;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && " Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.861029E-13;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*2.59E+12;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  feet                    (ft³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*0.111111;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*9;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  feet                    (ft²)".equals(from.getSelectedItem().toString()) && "Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.58701E-8;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*2.788E+7;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd²)".equals(from.getSelectedItem().toString()) && "Cubic miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.22831E-7;
            l2.setText(String.valueOf(conv));
        }else if("Cubic miles                  (mi³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*3.098E+6;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  yards                 (yd³)".equals(from.getSelectedItem().toString()) && "Cubic  yards                 (yd³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  miles                  (mi³)".equals(from.getSelectedItem().toString()) && "Cubic  miles                  (mi³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  feet                    (ft³)".equals(from.getSelectedItem().toString()) && " Cubic  feet                    (ft³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  millimetres        (mm³)".equals(from.getSelectedItem().toString()) && "Cubic  millimetres        (mm³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if(" Cubic  centimetres      (cm³)".equals(from.getSelectedItem().toString()) && " Cubic  centimetres      (cm³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  kilometres        (km³)".equals(from.getSelectedItem().toString()) && "Cubic  kilometres        (km³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }else if("Cubic  metres              (m³)".equals(from.getSelectedItem().toString()) && "Cubic  metres              (m³)".equals(to.getSelectedItem().toString())){
            conv = amount*1;
            l2.setText(String.valueOf(conv));
        }
    }//GEN-LAST:event_bconvActionPerformed

    private void bdelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bdelActionPerformed
        String backspace = null;
        if(l1.getText().length()>0){
            StringBuilder  stb = new StringBuilder(l1.getText());
            stb.deleteCharAt(l1.getText().length()-1);
            backspace = stb.toString();
            l1.setText(backspace);
        }
    }//GEN-LAST:event_bdelActionPerformed

    private void bacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bacActionPerformed

        l1.setText("");
        l2.setText("");
    }//GEN-LAST:event_bacActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        String num = l1.getText() + b6.getText();
        l1.setText(num);
    }//GEN-LAST:event_b6ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        String num = l1.getText() + b2.getText();
        l1.setText(num);
    }//GEN-LAST:event_b2ActionPerformed

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        String num = l1.getText() + b1.getText();
        l1.setText(num);
    }//GEN-LAST:event_b1ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        String num = l1.getText() + b5.getText();
        l1.setText(num);
    }//GEN-LAST:event_b5ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        String num = l1.getText() + b9.getText();
        l1.setText(num);
    }//GEN-LAST:event_b9ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        String num = l1.getText() + b8.getText();
        l1.setText(num);
    }//GEN-LAST:event_b8ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        String num = l1.getText() + b7.getText();
        l1.setText(num);
    }//GEN-LAST:event_b7ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        String num = l1.getText() + b3.getText();
        l1.setText(num);
    }//GEN-LAST:event_b3ActionPerformed

    private void b0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b0ActionPerformed
        String num = l1.getText() + b0.getText();
        l1.setText(num);
    }//GEN-LAST:event_b0ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        String num = l1.getText() + b4.getText();
        l1.setText(num);
    }//GEN-LAST:event_b4ActionPerformed

    private void bpointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bpointActionPerformed

        if(!l1.getText().contains(".")){
            l1.setText(l1.getText() + bpoint.getText());
        }
    }//GEN-LAST:event_bpointActionPerformed

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
     
    }//GEN-LAST:event_jLabel7MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(volume.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(volume.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(volume.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(volume.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new volume().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b0;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JButton bac;
    private javax.swing.JButton bconv;
    private javax.swing.JButton bdel;
    private javax.swing.JButton bpoint;
    private javax.swing.JComboBox<String> from;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l2;
    private javax.swing.JLabel l5;
    private javax.swing.JComboBox<String> to;
    // End of variables declaration//GEN-END:variables
}
